export const USER_SIGNIN_API = 'USER_SIGNIN_API';



//------------------login ------
export const USLOGIN = 'USLOGIN';


//-------------get project category ---------


export const GET_ALL_PROJECT_CATEGORY_SAGA = 'GET_ALL_PROJECT_CATEGORY_SAGA';


export const GET_ALL_PROJECT_CATEGORY = 'GET_ALL_PROJECT_CATEGORY';