//-----------action----------
export const GET_TASK_API = 'GET_TASK_API';

//---------------saga--------------

export const GET_TASKLIST_API = 'GET_TASKLIST_API';
export const ADD_TASK_API = 'ADD_TASK_API';
export const CHECK_TASK_API = 'CHECK_TASK_API';
export const DELETE_TASK_API = 'DELETE_TASK_API';
export const REJECT_TASK_API = 'REJECT_TASK_API';



