import React from 'react'

export default function PageNotFound(props) {
    return (
        <div>
            Không tìm thấy trang {props.match.url}
        </div>
    )
}
