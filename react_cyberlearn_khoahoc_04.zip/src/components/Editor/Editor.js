import React from 'react'

export default function Editor() {
    
    return (
        <div>
            
        </div>
    )
}
